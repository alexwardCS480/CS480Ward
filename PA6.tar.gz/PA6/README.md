Alex Ward PA2
========================================


Build Notes:
---------------------

*This example requires GLM*
*On ubuntu it can be installed with this command*

>$ sudo apt-get install libglm-dev

*On a Mac you can install GLM with this command(using homebrew)*
>$ brew install glm

To build this example just 

>$ cd build
>$ make


The excutable will be put in bin



Run Notes:
------------------------------

The hockey table rotates and orbits so the grader can see all sides. The color changes slightly between triangles in order to see the object correctly. 

Press the right mouse button to open the programs menu. From the menu you can pause the hockey table's rotation and orbit.


Press the left mouse button to reverse the hockey table's orbit.
